---
title: "Welcome"
weight: 1
---

`Hugo-Scroll` theme alternates colors of sections that are placed on single page.
The landing screen is meant to be visually striking.

Single-page approach is oriented towards small to medium content length, that won't overwhelm the user.
You can also delegate lengthier, less important or more sizeable content to [dedicated pages](services).

> The belly rules the mind. --- spanish proverb

By the way this welcome section won't show in the cover menu.
