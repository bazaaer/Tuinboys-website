---
title: "The single page referenced to by the Legal button on the cover page"
---
This file is a single page and is referenced by the button `Legal` on the cover start page.

It can contain more or additional information than the dedicated section on the homepage.
